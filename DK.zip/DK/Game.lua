local Game = {
    background = love.graphics.newImage("Back.png"),
    player = nil,
    wires = {},
    controlPanel = nil,
    level = nil,
    reality = nil,
    decoTime = 3,
    decoTimeMax = 3,
    tempWireStart = nil,
    tempWireDuration = nil,
    levelTimer = 0,
    firstWireLinked = false,
    timerContinue = 0,
    alarmTimer = 100,
}
Game.__index = Game

local Player = require 'Player'
local WireBucket = require 'WireBucket'
local Wire = require 'Wire'
local ControlPanel = require 'ControlPanel'
local Level = require 'Level'
local Reality = require 'Reality'


function Game.new()
    local self = setmetatable({}, Game)
    self.player = Player.new(30,220)
    self.level = Level.new(1)
    self.controlPanel = ControlPanel.new()
    self.reality = Reality.new()
    return self
end

function Game:nextLevel()
    self.player = Player.new(30,220)
    LevelBase[self.level.index*2] = self.levelTimer
    self.level = Level.new(self.level.index+1)
    self.wires = {}
    self.decoTime = 5
    self.tempWireStart = nil
    self.tempWireDuration = nil
    score = score + self.levelTimer
    self.levelTimer = 0
    self.firstWireLinked = false
    self.controlPanel.controls = {0,0,0,0,0,0,0,0,}
    self.timerContinue = 0
    self.alarmTimer = 100
end

function Game:reloadLevel()
    self.player = Player.new(30,220)
    self.wires = {}
    self.decoTime = 5
    self.tempWireStart = nil
    self.tempWireDuration = nil
    self.levelTimer = 0
    self.firstWireLinked = false
    self.controlPanel.controls = {0,0,0,0,0,0,0,0,}
    self.timerContinue = 0
    self.alarmTimer = 100
end

function Game:update(dt)
    if self.level:hasFinished(self.player.x,self.player.y) and not self.player.win then
        self.player.win = true
        if not mute then levelComplete:play() end
    end
    if self.player.win then
         self.timerContinue = self.timerContinue + dt
    end
    if self.decoTime <= 0 or self.player.dead then
        self.timerContinue = self.timerContinue + dt
    end
    self.player:update(dt,self.controlPanel.controls,self.level:isSafe(self.player.x,self.player.y))
    for _,currentWire in ipairs(self.wires) do
        currentWire:update(dt)
    end
    local i = 1
    while i <= #self.wires do
        if self.wires[i].dead then
            self.controlPanel:removeFromPanel(self.wires[i].indexInPanel)
            self.wires[i] = self.wires[#self.wires]
            self.wires[#self.wires] = nil
            if not mute then wireCut:play() end
        else
            i = i + 1
        end
    end

    if self.tempWireStart then
        if self.tempWireDuration + dt*2 < self.tempWireDurationMax then
            self.tempWireDuration = self.tempWireDuration + dt*2
        end
    end

    if #self.wires == 0 then
        if self.decoTime > 0 then
            self.decoTime = self.decoTime - dt
        end
    end

    if self.firstWireLinked then
        if not self.player.win and not self.player.dead and self.decoTime > 0 then
            self.levelTimer = self.levelTimer + dt
        end

        if self.player.win then
            self.reality:update("win",dt)
        elseif self.player.dead or self.decoTime <= 0 then
            self.reality:update("disconnected",dt)
        elseif #self.wires == 0 or not self.level:isSafe(self.player.x,self.player.y) then
            self.reality:update("disconnecting",dt)
        else
            self.reality:update("normal",dt)
        end
    else
        self.reality:update("normal",dt)
    end

    if (not self.level:isSafe(self.player.x,self.player.y) or #self.wires == 0) and not self.player.dead and self.decoTime>0 and not self.player.win and self.firstWireLinked then
        if self.decoTime < 0.9 * self.decoTimeMax and self.alarmTimer > self.decoTime then
            if not mute then alarmBeep:play() end
            self.alarmTimer = self.decoTime *4/5
        elseif self.alarmTimer > self.player.radius then
            if not mute then alarmBeep:play() end
            self.alarmTimer = self.player.radius * 4/5
        end
    else
        self.alarmTimer = 100
    end
end

function Game:draw()
    
    local mx, my = love.mouse.getPosition()
    love.graphics.setColor(darkGreen)
    love.graphics.rectangle("fill",0,0,800,600)
    love.graphics.push()
    love.graphics.translate(200-self.player.x, 0)
    self.level:draw()
    self.player:draw()
    love.graphics.pop()
    love.graphics.setColor(255, 255, 255, 255)
    love.graphics.draw(self.background,0,0)
    self.reality:draw()
    love.graphics.setLineWidth(3)

    self.controlPanel:draw()

    if self.tempWireStart then
        love.graphics.setColor(255, 255 *(1-(self.tempWireDurationMax - self.tempWireDuration)/self.tempWireDurationMax),  255 *(1-(self.tempWireDurationMax - self.tempWireDuration)/self.tempWireDurationMax), 255)
        love.graphics.line(self.tempWireStart[1], self.tempWireStart[2],self.tempWireStart[1],(self.tempWireStart[2]-my)*2/3+my,mx,(self.tempWireStart[2]-my)/3+my,mx, my)
    end
    for _,currentWire in ipairs(self.wires) do
        currentWire:draw()
    end
    if self.firstWireLinked then
        if (#self.wires == 0 or not self.level:isSafe(self.player.x,self.player.y)) and not self.player.win then
            love.graphics.setFont(fontBig)
            love.graphics.setColor(red)

            if  not self.player.dead and #self.wires == 0 and self.decoTime > 0 then
                love.graphics.printf("DISCONNECTED IN "..math.ceil(self.decoTime*10)/10,0, 180, 800,"center")
            elseif not self.level:isSafe(self.player.x,self.player.y) and not self.player.dead then
                love.graphics.printf("LOSING CONNECTION",0, 180, 800,"center")
            else
                if self.timerContinue <= 1 then
                    love.graphics.printf("DISCONNECTED",0, 180, 800,"center")
                else
                    love.graphics.printf("Click to Retry",0, 180, 800,"center")
                end
            end
            love.graphics.setFont(fontNormal)
        else
            self.decoTime = self.decoTimeMax
        end
        love.graphics.setFont(fontBig)
        love.graphics.setColor(gold)
        love.graphics.printf(math.ceil(self.levelTimer*10)/10 .." sec",416,480,368,"center")
        love.graphics.setFont(fontNormal)
    else
        love.graphics.setColor(gold)
        love.graphics.printf("Connect the first wire to start",416,480,368,"center")
    end

    if self.player.win then
        love.graphics.setColor(white)
        love.graphics.setFont(fontBig)
        if self.timerContinue <= 1 then
            love.graphics.printf("Connected !",0, 180, 800,"center")
        else
            love.graphics.printf("Click to continue",0, 180, 800,"center")
        end
        
        love.graphics.setFont(fontNormal)
    end
    love.graphics.setColor(gold)
    love.graphics.setFont(fontTiny)
    love.graphics.print("Level "..self.level.index, 420,565)
    love.graphics.setFont(fontNormal)

end

function Game:mousepressed(x,y,button)
    if button == "l" then
        if WireBucket.isIn(x,y) then
            self.tempWireStart = {x,y}
            self.tempWireDurationMax = 8 + math.random(10)
            self.tempWireDuration = self.tempWireDurationMax
        else
            if #self.wires > 0 then
                local i = 1
                while i < #self.wires and self.wires[i]:distanceToWire(x,y) > 10 do
                    i = i + 1
                end
                if self.wires[i]:distanceToWire(x,y) <=10 then
                    self.controlPanel:removeFromPanel(self.wires[i].indexInPanel)
                    self.tempWireStart = {self.wires[i].x1,self.wires[i].y1}
                    self.tempWireDuration = self.wires[i].duration
                    self.tempWireDurationMax = self.wires[i].durationMax
                    self.wires[i] = self.wires[#self.wires]
                    self.wires[#self.wires] = nil
                end
            end
        end
    elseif button == "r" then
        if #self.wires >0 then
            local i = 1
            while i < #self.wires and self.wires[i]:distanceToWire(x,y) > 10 do
                i = i + 1
            end
            if self.wires[i]:distanceToWire(x,y) <=10 then
                self.controlPanel:removeFromPanel(self.wires[i].indexInPanel)
                self.wires[i] = self.wires[#self.wires]
                self.wires[#self.wires] = nil
                if not mute then wireCut:play() end
            end
        end
    end
end

function Game:mousereleased(x,y,button)
        if button == "l" then
        if self.player.win and self.timerContinue > 1 then
            if self.level.index <11 then
                self:nextLevel()
            else
                onEndScreen = true
                inMenu = true
                score = score + self.levelTimer
            end
        elseif self.player.dead and self.timerContinue > 1 then
            self:reloadLevel()
        end
        if self.tempWireStart and self.controlPanel.isIn(x,y) then
            local indexInPanel = self.controlPanel.getIndex(x)
            self.controlPanel:addToPanel(indexInPanel)
            local newWire = Wire.new(self.tempWireStart[1],self.tempWireStart[2],x,y,indexInPanel,self.tempWireDuration,self.tempWireDurationMax)
            self.wires[#self.wires+1] = newWire
            if not mute then wireAdded:play() end
            self.firstWireLinked = true
        end
        self.tempWireStart = nil
    end
end

return Game