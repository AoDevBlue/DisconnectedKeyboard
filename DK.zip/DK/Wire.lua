local Wire = {

}
Wire.__index = Wire

function Wire.new(x1, y1, x2, y2, indexInPanel, duration, durationMax)
    local self = setmetatable({}, Wire)
  	self.x1 = x1
  	self.y1 = y1
  	self.x2 = x2
  	self.y2 = y2
    self.xi1 = x1
    self.xi2 = x2
    self.yi1 = (y1 - y2) *2/3 + y2
    self.yi2 = (y1 - y2) /3 + y2
    self.t = 0
    self.vt = 1 + math.random(7)
  	self.indexInPanel = indexInPanel
  	self.durationMax = durationMax
  	self.duration = duration
  	self.dead = false
	return self
end

function Wire:update(dt)
	if self.duration > 0 then
  	self.duration = self.duration - dt
	else
		self.dead = true
	end
    self.t = self.t + dt / self.vt
    if self.t > 1 then 
        self.vt = 1 + math.random(7)
        self.t = 0
    end
end

function Wire:draw()
    love.graphics.setLineWidth(10)
    love.graphics.setColor(darkGreen)
    love.graphics.line(self.x1, self.y1, self.xi1, self.yi1, self.xi2, self.yi2, self.x2, self.y2)
    love.graphics.setLineWidth(3)
	love.graphics.setColor(255, 255 *(1- (self.durationMax - self.duration)/self.durationMax), 255 *(1- (self.durationMax - self.duration)/self.durationMax), 255)
	love.graphics.line(self.x1, self.y1, self.xi1, self.yi1, self.xi2, self.yi2, self.x2, self.y2)
    -- love.graphics.setColor(grey)
    if self.t < 0.33 then
        love.graphics.circle("fill",self.x1,self.y1+self.t*(self.y2-self.y1),5)
    elseif self.t < 0.66 then
        love.graphics.circle("fill",self.x1+(self.t-0.33)/0.33 *(self.x2-self.x1),self.yi1+(self.t-0.33)/0.33*(self.yi2-self.yi1),5)
    else
        love.graphics.circle("fill",self.x2,self.y1+self.t*(self.y2-self.y1),5)
    end
end

function Wire:distanceToWire(x,y)
    local d1 = distPointToLine(x,y,self.x1,self.y1,self.xi1,self.yi1)
    local d2 = distPointToLine(x,y,self.xi1,self.yi1,self.xi2,self.yi2)
    local d3 = distPointToLine(x,y,self.xi2,self.yi2,self.x2,self.y2)
    return math.min(d1,d2,d3)
end

function distPointToLine(px,py,x1,y1,x2,y2)
    local dx,dy = x2-x1,y2-y1 
    local length = math.sqrt(dx*dx+dy*dy)
    dx,dy = dx/length,dy/length
    local posOnLine = dx*(px-x1) + dy*(py-y1)
    if posOnLine < 0 then
        -- first end point is closest
        dx,dy = px-x1,py-y1
        return math.sqrt(dx*dx+dy*dy)
    elseif posOnLine > length then
        -- second end point is closest
        dx,dy = px-x2,py-y2
        return math.sqrt(dx*dx+dy*dy)    
    else
        -- point is closest to some part in the middle of the line
        return math.abs( dy*(px-x1) - dx*(py-y1))
    end
end

return Wire