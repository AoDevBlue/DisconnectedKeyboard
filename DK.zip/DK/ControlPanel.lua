local ControlPanel = {
	controls = {0,0,0,0,0,0,0,0,},
	link_up = love.graphics.newImage("link_up.png"),
	link_left = love.graphics.newImage("link_left.png"),
	link_down = love.graphics.newImage("link_down.png"),
	link_right = love.graphics.newImage("link_right.png"),
	link_up_fast = love.graphics.newImage("link_up_fast.png"),
	link_left_fast = love.graphics.newImage("link_left_fast.png"),
	link_down_fast = love.graphics.newImage("link_down_fast.png"),
	link_right_fast = love.graphics.newImage("link_right_fast.png"),
}
ControlPanel.__index = ControlPanel

function ControlPanel.new()
	local self = setmetatable({}, ControlPanel)
	return self
end

function ControlPanel.isIn(x,y)
	if x >= 16 and x <= 367 and y >= 16 and y <= 60 then
		return true
	else
		return false
	end
end

function ControlPanel.getIndex(x)
	return math.floor((x - 16) / 45 ) + 1
end

function ControlPanel:addToPanel(index)
	self.controls[index] = self.controls[index] + 1
end

function ControlPanel:removeFromPanel(index)
	self.controls[index] = self.controls[index] - 1
end

function ControlPanel:draw()
	if self.controls[1] ~= 0 then
		love.graphics.draw(self.link_up,16,16)
	end
	if self.controls[2] ~= 0 then
		love.graphics.draw(self.link_left,61,16)
	end
	if self.controls[3] ~= 0 then
		love.graphics.draw(self.link_down,106,16)
	end
	if self.controls[4] ~= 0 then
		love.graphics.draw(self.link_right,151,16)
	end
	if self.controls[5] ~= 0 then
		love.graphics.draw(self.link_up_fast,196,16)
	end
	if self.controls[6] ~= 0 then
		love.graphics.draw(self.link_left_fast,241,16)
	end
	if self.controls[7] ~= 0 then
		love.graphics.draw(self.link_down_fast,286,16)
	end
	if self.controls[8] ~= 0 then
		love.graphics.draw(self.link_right_fast,331,16)
	end

end

return ControlPanel