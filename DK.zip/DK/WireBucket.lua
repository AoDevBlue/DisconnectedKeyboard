local WireBucket = {

}
WireBucket.__index = WireBucket

function WireBucket.isIn(x,y)
	if x >= 106 and x <=277 and y >= 371 and y <= 415 then
		return true
	else
		return false
	end
end

return WireBucket