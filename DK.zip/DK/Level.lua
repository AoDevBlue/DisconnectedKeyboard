local Level = {
	matrix = nil,
	index = nil,
	-- endless = false,
}
Level.__index = Level

function Level.new(index)
	local self = setmetatable({}, Level)
	self.matrix = LevelBase[index*2-1]
	self.index = index
	return self
end

function Level:isSafe(x,y)
	blockType = self.matrix[math.floor(y/50) + 1][math.floor(x/50 + 1)]
	if blockType == 1 or blockType == 6 then
		return true
	elseif blockType == 2 then
		if x % 50 <= y % 50 then
			return true
		else
			return false
		end
	elseif blockType == 3 then
		if 50 - (x % 50) <= y % 50 then
			return true
		else
			return false
		end
	elseif blockType == 4 then
		if 50 - (x % 50) >= y % 50 then
			return true
		else
			return false
		end
	elseif blockType == 5 then
		if x % 50 >= y % 50 then
			return true
		else
			return false
		end
	else
		return false
	end
end

function Level:update(dt)

end

function Level:hasFinished(x,y)
	blockType = self.matrix[math.floor(y/50) + 1][math.floor(x/50 + 1)]
	if blockType == 6 then
		return true
	else
		return false
	end
end

function Level:draw()
	love.graphics.setColor(lightGreen)
	for i=1,#self.matrix do
    	for j=1,#self.matrix[i] do
    		if self.matrix[i][j] == 1 then
    			love.graphics.rectangle("fill",50*(j-1)+384,50*(i-1)+16,50,50)
    		elseif self.matrix[i][j] == 2 then
    			love.graphics.polygon('fill', 50*(j-1)+384,50*(i-1)+16,50*(j-1)+384,50*(i-1)+16+50,50*(j-1)+384+50,50*(i-1)+16+50)
    		elseif self.matrix[i][j] == 3 then
    			love.graphics.polygon('fill', 50*(j-1)+384,50*(i-1)+16+50,50*(j-1)+384+50,50*(i-1)+16+50,50*(j-1)+384+50,50*(i-1)+16)
    		elseif self.matrix[i][j] == 4 then
    			love.graphics.polygon('fill', 50*(j-1)+384,50*(i-1)+16,50*(j-1)+384,50*(i-1)+16+50,50*(j-1)+384+50,50*(i-1)+16)
    		elseif self.matrix[i][j] == 5 then
    			love.graphics.polygon('fill', 50*(j-1)+384,50*(i-1)+16,50*(j-1)+384+50,50*(i-1)+16+50,50*(j-1)+384+50,50*(i-1)+16)
    		elseif self.matrix[i][j] == 6 then
    			love.graphics.setColor(gold)
    			love.graphics.rectangle("fill",50*(j-1)+384,50*(i-1)+16,50,50)
    			love.graphics.setColor(lightGreen)
    		end
    	end
    end
end

return Level