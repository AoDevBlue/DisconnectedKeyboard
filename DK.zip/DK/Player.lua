local Player = {
}
Player.__index = Player

function Player.new(x, y)
	local self = setmetatable({}, Player)
  	self.x = x
  	self.y = y
  	self.radius = 15
  	self.maxRadius = 15
  	self.dead = false
  	self.win = false
	return self
end

function Player:update(dt,controls,safe)
	local vx = 40
	local vy = 40
	local vxMultiplier = 0
	local vyMultiplier = 0

	vyMultiplier = vyMultiplier - controls[1]
	vxMultiplier = vxMultiplier - controls[2]
	vyMultiplier = vyMultiplier + controls[3]
	vxMultiplier = vxMultiplier + controls[4]
	vyMultiplier = vyMultiplier - 3 * controls[5]
	vxMultiplier = vxMultiplier - 3 * controls[6]
	vyMultiplier = vyMultiplier + 3 * controls[7]
	vxMultiplier = vxMultiplier + 3 * controls[8]

	if not safe and not self.dead then
		self.radius = self.radius - dt * self.maxRadius
		if self.radius < 0 then
			self.radius = 0.01
			self.dead = true
		end
	end

	if safe and not self.dead and self.radius < self.maxRadius then
		self.radius = self.radius + dt * self.maxRadius / 2
		if self.radius > self.maxRadius then
			self.radius = self.maxRadius
		end
	end

	if not self.dead and not self.win then
		self.x = self.x + vx * vxMultiplier * dt
		self.y = self.y + vy * vyMultiplier * dt
		if self.y - self.radius < 0 then
			self.y = self.radius
		end
		if self.y + self.radius > 400 then
			self.y = 400 - self.radius
		end
	end

end

function Player:draw()
	love.graphics.setColor(gold)
	love.graphics.circle( "fill", self.x+384, self.y+16, self.radius, 100 )
end

return Player