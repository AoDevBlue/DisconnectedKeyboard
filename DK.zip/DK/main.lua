
local Game = require 'Game'

-- Constants

fontNormal = love.graphics.newFont("visitor1.ttf", 32)
fontBig = love.graphics.newFont("visitor1.ttf", 64)
fontTiny = love.graphics.newFont("visitor1.ttf", 16)
splash = love.graphics.newImage("splash.png")
story = love.graphics.newImage("story.png")
tutorial = love.graphics.newImage("tutorial.png")
love.graphics.setFont(fontNormal)
lightBlue = {30, 190, 200, 255}
red = {255,40,40,255}
yellow = {245,245,20,255}
grey = {190,190,190,255}
green = {50,255,50,255}
darkGreen = {31,80,46,255}
lightGreen = {23,148,96,255}
white = {255,255,255,255}
gold = {220,158,81,255}
LevelBase = require 'LevelBase'

-- Sounds
alarmBeep = love.audio.newSource("AlarmBeep.wav", "static")
alarmBeep:setVolume(0.6)
levelComplete = love.audio.newSource("levelComplete.wav", "static")
levelComplete:setVolume(0.6)
wireAdded = love.audio.newSource("wireAdded.wav", "static")
wireAdded:setVolume(0.6)
wireCut = love.audio.newSource("wireCut.wav", "static")
wireCut:setVolume(0.6)

-- Music
music = love.audio.newSource("AnInvisibleSweet.ogg")
music:setLooping(true)
music:setVolume(0.4)
music:play()


inMenu = true
mute = false
local onSplashScreen = true
local onStoryScreen = false
local onTutoScreen = false
onEndScreen = false
score = 0
local splashFrame = 1
local splashFrameTimer = 0
local disconnecting1 = love.graphics.newImage("chara_disconnecting1.png")
local disconnecting2 = love.graphics.newImage("chara_disconnecting2.png")
local win1 = love.graphics.newImage("chara_win1.png")
local mouseHasBeenReleased = true

function love.load()
	love.window.setMode(800, 600)
	love.window.setTitle("Disconnected Keyboard")

	math.randomseed(os.time())

	game = Game.new()
end

function love.update(dt)
	if inMenu then
		if onSplashScreen then
			splashFrameTimer = splashFrameTimer + dt
			if splashFrameTimer > 0.5 then
				splashFrameTimer = 0
				splashFrame = splashFrame % 2 + 1
			end
		end
	end
	if not inMenu then
		game:update(dt)
	end
end

function love.draw()
	if inMenu then
		if onSplashScreen then
			love.graphics.setColor(white)
			love.graphics.draw(splash,0,0)
			if splashFrame == 1 then
				love.graphics.draw(disconnecting1,218,300)
			else
				love.graphics.draw(disconnecting2,218,300)
			end
		elseif onStoryScreen then
			love.graphics.setColor(white)
			love.graphics.draw(story,0,0)
		elseif onTutoScreen then
			love.graphics.setColor(white)
			love.graphics.draw(tutorial,0,0)
		elseif onEndScreen then
			love.graphics.setColor(darkGreen)
			love.graphics.rectangle("fill",0,0,800,600)
			love.graphics.setColor(gold)
			love.graphics.printf("Congratulations!\n\nYou would make a good keyboard!\n\nYou finished in "..math.ceil(score*10)/10 .." sec!",0,100,800,"center")
			love.graphics.setColor(white)
			love.graphics.draw(win1,218,300)
		end
	end
	if not inMenu then
		game:draw()
	end

	love.graphics.setColor(gold)
	love.graphics.setFont(fontTiny)
	if mute then
		love.graphics.print("Sounds : Off",660,565)
	else
		love.graphics.print("Sounds : On", 660,565)
	end
	love.graphics.setFont(fontNormal)
end

function love.mousepressed(x, y, button)
	if x > 660 and y > 565 then
		if mute then
			mute = false
			music:setVolume(0.4)
		else
			mute = true
			music:setVolume(0)
		end
	elseif inMenu then
		if onSplashScreen then
			onSplashScreen = false
			onStoryScreen = true
		elseif onStoryScreen and mouseHasBeenReleased then
			onStoryScreen = false
			onTutoScreen = true
		elseif onTutoScreen and mouseHasBeenReleased then
			onTutoScreen = false
			inMenu = false
		elseif onEndScreen and mouseHasBeenReleased then
			onEndScreen = false
			onSplashScreen = true
		end
	else
		game:mousepressed(x,y,button)
	end
end

function love.mousereleased(x, y, button)
	mouseHasBeenReleased = true
	if not inMenu then
		game:mousereleased(x,y,button)
	end
end

function derp(me)
	return "derp : "..me
end

