local Reality = {
    normal1 = love.graphics.newImage("chara_normal1.png"),
    normal2 = love.graphics.newImage("chara_normal2.png"),
    normal3 = love.graphics.newImage("chara_normal3.png"),
    win1 = love.graphics.newImage("chara_win1.png"),
    disconnecting1 = love.graphics.newImage("chara_disconnecting1.png"),
    disconnecting2 = love.graphics.newImage("chara_disconnecting2.png"),
    disconnected1 = love.graphics.newImage("chara_disconnected1.png"),
    disconnected2 = love.graphics.newImage("chara_disconnected2.png"),
}
Reality.__index = Reality

function Reality.new()
    local self = setmetatable({}, Reality)
  	self.state = "normal"
    self.frame = 1
    self.timer = 0
    self.timerMax = 0.5
	return self
end

function Reality:update(state,dt)
	if state == self.state then
        self.timer = self.timer + dt
        if self.timer > self.timerMax then
            self.timer = 0
            if state ~= "win" then
                if state == "normal" then
                    self.frame = self.frame % 3 + 1
                else
                    self.frame = self.frame % 2 + 1
                end
            end
        end
    else
        self.state = state
        self.frame = 1
    end
end

function Reality:draw()
	if self.state == "normal" then
        if self.frame == 1 then
            love.graphics.draw(self.normal1,16,432)
        elseif self.frame == 2 then
            love.graphics.draw(self.normal2,16,432)
        else
            love.graphics.draw(self.normal3,16,432)
        end
    elseif self.state == "win" then
        love.graphics.draw(self.win1,16,432)
    elseif self.state == "disconnecting" then
        if self.frame == 1 then
            love.graphics.draw(self.disconnecting1,16,432)
        else
            love.graphics.draw(self.disconnecting2,16,432)
        end
    elseif self.state == "disconnected" then
        if self.frame == 1 then
            love.graphics.draw(self.disconnected1,16,432)
        else
            love.graphics.draw(self.disconnected2,16,432)
        end
    end
end

return Reality